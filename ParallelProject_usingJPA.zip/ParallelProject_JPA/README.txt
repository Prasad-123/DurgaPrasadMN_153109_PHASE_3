Create table customer_jpa(mobilenumber varchar2(10) primary key,name varchar2(20),balance Number(20,2));


Create table wallet_jpa(mobilenumber varchar2(10),Transactiontype varchar2(20),transactiondate date,balance Number(20,2));